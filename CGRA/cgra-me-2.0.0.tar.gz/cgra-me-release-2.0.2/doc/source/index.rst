.. CGRA-ME documentation master file, created by
   sphinx-quickstart on Tue Jun  6 16:40:11 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to CGRA-ME's documentation!
===================================

Source Code Documentation
[`as HTML <./doxygen/html/index.html>`_]
[`as one PDF <./doxygen/latex/refman.pdf>`_]

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   gettingstarted
   userguide
   limitation
   contributors_guide
