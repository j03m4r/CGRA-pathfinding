#include "coreir.h"
#include "assert.h"

#include "stdio.h"
#include "stdlib.h"

void print(char* a) {
  printf("%s",a); printf("\n"); fflush(stdout);
}

int main() {

  return 0;
}
