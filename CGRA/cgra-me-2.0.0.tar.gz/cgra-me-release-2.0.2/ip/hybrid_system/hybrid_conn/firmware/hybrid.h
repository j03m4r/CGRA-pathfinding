	.set io_top_0, 4194304
	.set io_top_1, 4194308
	.set io_top_2, 4194312
	.set io_top_3, 4194316
	.set counter , 4194320
	.set endport, 4194324
	.set reset, 4194328
	.set selport, 4194332
	.set mem_0, 0
	.set mem_1, 1048576
	.set mem_2, 2097152
	.set mem_3, 3145728
