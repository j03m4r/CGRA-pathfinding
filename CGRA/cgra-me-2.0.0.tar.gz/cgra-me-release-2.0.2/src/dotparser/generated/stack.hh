// A Bison parser, made by GNU Bison 3.3.2.

// Starting with Bison 3.2, this file is useless: the structure it
// used to define is now defined with the parser itself.
//
// To get rid of this file:
// 1. add 'require "3.2"' (or newer) to your grammar file
// 2. remove references to this file from your build system.
